﻿SPREADEX DRAW

designed using OOP principles, some objects inherit the properties of its parents (Square <- Rectangle, Circle <- Ellipse)
stored drawing in primitives char[] to reduce bloating
used a helper to streamline combining multiple matrices
issues with textbox not being able to escape to a newline, no time to fix